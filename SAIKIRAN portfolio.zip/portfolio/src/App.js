
import React from "react";
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-white text-gray-900 p-8">
      <header className="mb-12 text-center">
        <h1 className="text-4xl font-bold mb-2">Your Name</h1>
        <p className="text-lg">Creative Professional | Portfolio Website</p>
      </header>

      <section className="mb-16">
        <h2 className="text-2xl font-semibold mb-4">About Me</h2>
        <p className="text-base leading-relaxed">
          This is a short bio about who you are, what you do, and what you're passionate about. You can customize this section to include your background, experience, and goals.
        </p>
      </section>

      <section className="mb-16">
        <h2 className="text-2xl font-semibold mb-6">My Work</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((item) => (
            <Card key={item} className="rounded-2xl shadow-md">
              <CardContent className="p-4">
                <h3 className="text-xl font-medium mb-2">Project Title {item}</h3>
                <p className="text-sm mb-4">
                  Brief description of the project. Highlight tools used and what it accomplished.
                </p>
                <Button variant="outline">View Project</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="mb-16">
        <h2 className="text-2xl font-semibold mb-4">Contact</h2>
        <p className="mb-4">Email: your.email@example.com</p>
        <Button>Download Resume</Button>
      </section>

      <footer className="text-center text-sm text-gray-500">
        © {new Date().getFullYear()} Your Name. All rights reserved.
      </footer>
    </div>
  );
}
