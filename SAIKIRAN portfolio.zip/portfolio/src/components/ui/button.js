
export function Button({ children, variant }) {
  const style = variant === "outline" ? "border border-black px-4 py-2" : "bg-black text-white px-4 py-2";
  return <button className={style}>{children}</button>;
}
